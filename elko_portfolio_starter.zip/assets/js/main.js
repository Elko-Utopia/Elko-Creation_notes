(function(){
  document.querySelectorAll('#year').forEach(el=> el.textContent = new Date().getFullYear());
  const btn = document.querySelector('.nav-toggle');
  const nav = document.querySelector('.site-nav');
  if(btn && nav){ btn.addEventListener('click', ()=> nav.classList.toggle('open')); }
})();